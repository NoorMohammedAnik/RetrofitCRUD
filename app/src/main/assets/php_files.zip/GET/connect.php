<?php 
define('host', 'localhost');
define('user', 'cseiiucc_user');
define('pass', 'c131051cse#');
define('db', 'cseiiucc_user');

$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
?>